
import React from 'react';
import { BrowserRouter, Route, Switch } from "react-router-dom";

import Help from './components/help'
import Home from './components/home'
import Mail from './components/mail'
import Other from './components/other'

class App extends React.Component{
  constructor( props ){
    super( props )

    this.state = {
      records: []
    }

    this.recordView = this.recordView.bind( this )
    setInterval( this.addRecord.bind( this ), 10000 )
  }

  addRecord(){
    this.setState( state => {
      const records = state.records.slice()
      const id = records.length + 1
      const record = {
        id:    id,
        isNew: true,
        name: `Record ${id}`
      }
      records.push( record )
      return { records }
    })
  }

  recordView( e ){
    const id = parseInt( e.currentTarget.attributes['data-id'].value )
    this.setState( state => {
      const records = state.records.slice()
      for( let r of records ){
        if( r.id === id ){
          r.isNew = false
          break
        }
      }
      return { records }
    })
  }

  render(){
    return (
      <div>
        <h1 style={{ background: '#333', color: 'white' }}>Header <small>{this.state.records.filter(r=>r.isNew).length}</small></h1>
        <BrowserRouter>
          <Switch>
            <Route exact path="/">
              <Home records={this.state.records} />
            </Route>
            <Route exact path="/mail">
              <Mail records={this.state.records} onRecordView={this.recordView} />
            </Route>
            <Route exact path="/help">
              <Help />
            </Route>
            <Route path="/*">
              <Other />
            </Route>
          </Switch>
        </BrowserRouter>
      </div>
    )
  }
}

export default App;
