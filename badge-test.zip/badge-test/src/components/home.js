
import React from 'react'
import { Link } from "react-router-dom"

const Home = ( props ) => {
  return (
    <div>
      <strong>Home</strong>
      <ul>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/mail">Mail - New: {props.records.filter(r=>r.isNew).length} :: Total: {props.records.length}</Link></li>
        <li><Link to="/help">Help</Link></li>
      </ul>
    </div>
  )
}

export default Home
