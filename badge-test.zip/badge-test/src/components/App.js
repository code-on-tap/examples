
const React = require( 'react' )
import { BrowserRouter, Route, Switch } from "react-router-dom";

import Help from './components/help'
import Home from './components/home'
import Mail from './components/mail'
import Other from './components/other'


const database = {
	records: [],
	count: ( isNew ) => {
		return database.get( isNew ).length
	},
	get: ( isNew ) => {
		if( isNew )
			return database.records.filter( r => r.isNew == isNew )
		else
			return database.records
	}
}


let started = false
function App(){
	if( !started ){
		started = true

		setInterval(()=>{
			const id = database.records.length + 1

			const record = {
				id: id,
				isNew: true,
				name: `Record ${id}`,
				read: () => {
					record.isNew = false
				}
			}
			database.records.push( record )
		}, 30000)
	}

	return (
		<div>
			<h1 style={{ background: '#333', color: 'white' }}>Header <small>{database.count( isNew )}</small></h1>
			<BrowserRouter>
				<Switch>
					<Route exact path="/">
						<Home database={database} />
					</Route>
					<Route exact path="/mail">
						<Mail database={database} />
					</Route>
					<Route exact path="/help">
						<Help />
					</Route>
					<Route path="/*">
						<Other />
					</Route>
				</Switch>
			</BrowserRouter>
		</div>
	)
}

export default App

