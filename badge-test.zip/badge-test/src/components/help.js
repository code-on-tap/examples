
import React from 'react'
import { Link } from "react-router-dom"

const Help = ( props ) => {
  return (
    <div>
      <Link to="/">Back</Link><br />
      <strong>Help</strong>
    </div>
  )
}

export default Help
