
import React from 'react'
import { Link } from "react-router-dom"

const Mail = ( props ) => {


  const items = []
  for( let record of props.records ){
    if( record.isNew ){
      items.push(<li data-id={record.id} key={record.id} onClick={props.onRecordView} style={{ cursor: 'pointer' }}>{record.name} small <small>New!</small></li>)
    }
    else{
      items.push(<li key={record.id} style={{ cursor: 'pointer' }}>{record.name}</li>)
    }
  }

  return (
    <div>
      <Link to="/">Back</Link><br />
      <strong>Home</strong>
      <ul>
        {items}
      </ul>
    </div>
  )
}

export default Mail
