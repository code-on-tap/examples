
import React from 'react'
import { Link } from "react-router-dom"

const Other = () => {
  return (
    <div>
      <Link to="/">Back</Link><br />
      <strong>Other</strong>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque vel fermentum est. Morbi vehicula risus in ligula pretium vulputate. Curabitur massa sem, feugiat nec ultrices vitae, vehicula nec eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur feugiat turpis sit amet varius laoreet. Sed ornare molestie sem, vitae varius nunc lobortis ac. Donec eget sapien id nisl tempor venenatis. Nullam nunc lorem, mollis ac euismod vehicula, finibus luctus enim. Ut sit amet mauris quis erat sagittis commodo. Suspendisse urna elit, finibus vel dictum et, posuere at arcu. Praesent non vehicula turpis, non ullamcorper nibh. Nunc non eros vel orci semper consequat vitae quis tellus. Aenean orci mauris, molestie non risus eu, tristique vulputate ex.</p>
      <p>Cras mi nunc, cursus non magna facilisis, finibus rhoncus urna. In hac habitasse platea dictumst. Nam at leo efficitur, tincidunt odio ac, accumsan odio. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Donec eget maximus augue, nec venenatis risus. Nunc fringilla risus ut vehicula tempus. Sed arcu tellus, luctus at gravida non, finibus sit amet purus.</p>
      <p>Curabitur in ante nisi. Vivamus viverra a risus vitae molestie. Cras sapien tortor, viverra eu sodales ac, porttitor at augue. Etiam ut porttitor dolor. Mauris congue est iaculis sollicitudin vehicula. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vestibulum erat posuere purus vulputate, ut sollicitudin sem pulvinar. Donec aliquet neque porta risus feugiat accumsan. Sed ut augue ipsum.</p>
      <p>Donec sit amet massa ac leo pulvinar rutrum. Duis blandit vestibulum tellus, vitae fringilla sem facilisis at. Vivamus elit augue, dignissim ut accumsan at, placerat vitae diam. Sed sollicitudin elementum nulla id placerat. Duis sollicitudin sollicitudin magna, tempus sodales neque hendrerit eget. Vestibulum a erat odio. Nunc tincidunt viverra sem, quis viverra augue posuere vel. Ut pellentesque facilisis nibh, id pellentesque est semper vel. Nunc sed purus est. Pellentesque nec ante ut est posuere vestibulum. Aenean ultricies vitae sem in feugiat. Nunc ultrices scelerisque odio, ac suscipit enim tempus blandit. Nunc vulputate ligula dictum, volutpat ante ac, lobortis massa. Nam non sollicitudin mi. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras bibendum ante in velit pellentesque, et ornare purus interdum.</p>
      <p>In pellentesque urna quam, at lobortis nunc gravida sed. Duis dolor augue, suscipit id consequat ut, vulputate sed magna. Praesent ultricies erat et justo malesuada vestibulum. Sed pharetra augue at magna facilisis, id vestibulum diam interdum. Vestibulum sed metus sed est mattis tristique. Vivamus semper dolor sit amet urna ornare pretium. Aenean at convallis lorem. Proin vulputate lacus sit amet faucibus vehicula. Aliquam quis sodales eros. Sed justo neque, tristique quis neque vel, tristique pellentesque justo. Mauris malesuada arcu quis odio aliquet convallis. Sed pellentesque vehicula diam, eu bibendum ligula eleifend ac.</p>
    </div>
  )
}

export default Other
